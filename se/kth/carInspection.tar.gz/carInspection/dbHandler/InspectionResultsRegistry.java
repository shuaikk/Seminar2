/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package se.kth.carInspection.dbHandler;

import java.util.ArrayList;

/**
 *
 * @author tmpuser-10209
 */
public class InspectionResultsRegistry {
    private ArrayList<InspectionsDTO> InspectionResults = new ArrayList<>();
    
    public InspectionResultsRegistry()
    {   addInspections();  }
    
    
    //Inspector enters result of the specified inspection. The result is either pass or fail.
    public void setInspectionsResults(ArrayList<InspectionsDTO> InspectionResults)     
    { 
        this.InspectionResults = InspectionResults;
      
    }
    
    public ArrayList<InspectionsDTO> getInspections()    
    {
        return InspectionResults;
    }
    
            
    private void addInspections() {
        InspectionResults.add(new InspectionsDTO("egine","unchecked"));
        InspectionResults.add(new InspectionsDTO("body","unchecked"));
        InspectionResults.add(new InspectionsDTO("light","unchecked"));
     }
    
}
